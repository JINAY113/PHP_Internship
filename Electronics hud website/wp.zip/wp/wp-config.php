<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'wp' );

/** MySQL database username */
define( 'DB_USER', 'root' );

/** MySQL database password */
define( 'DB_PASSWORD', '' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'Os9`w(@QJ9_)NDv{q6V53(e8MID/D0%k;ZdN%trrLGJyH7KuM,78yy*XsGXvLMJ2' );
define( 'SECURE_AUTH_KEY',  '(}|wnRAhX%gl<Q@/+]%qBpNv^+BRJvu:wi4[`/ %| RS?o4#Ib!~F24:`~pPe$CX' );
define( 'LOGGED_IN_KEY',    '1M;H;s}tJwwIYwV;=sp2;Pv`,usB6Z>{X7[H-`q&P4[rSVa/tN#Q/W%`wd)ChUvt' );
define( 'NONCE_KEY',        '}$2U3l|M  jJEzy}-Xr|1kWWmS~blw0ux7(mkRCfFq4o{JY]ErEC@&@YVx Byvr6' );
define( 'AUTH_SALT',        'Clx$0P}>mi|ZO,-1[N_bhC60EZt{<=j|V_)=ad6$3LW)xZ/dxzP]};_u>.&hvh@!' );
define( 'SECURE_AUTH_SALT', ']=fx]Es3pYk<D+E_x$@n/hui=f?~Oyde#^n17#?!zLv0K0?Awl=lB hJ32@]^P;`' );
define( 'LOGGED_IN_SALT',   '1n7k:Bl1{*#T#P`n4,S3Pn9xNnyz-awoceN-07^8?w|mi&jz!Y&.^q]%2h9!%TEm' );
define( 'NONCE_SALT',       'ObUz>.ea.e42OL=tR4mTq/4>>5Ts0nlT%[8+?dj580$(sb}ad9cgzvf|haABSn2-' );

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'jp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
